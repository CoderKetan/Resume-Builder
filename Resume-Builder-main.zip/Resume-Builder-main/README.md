# Resume-Builder
A web-based tool designed for students and job seekers to create professional resumes effortlessly. Features a user-friendly interface for real-time data entry and one-click PDF generation. ​Key Features: ​Live Preview ​Multiple Templates ​Professional PDF Export ​Fully Responsive Design ​Tech: HTML, CSS, JavaScript.
